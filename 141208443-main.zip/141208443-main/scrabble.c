#include <stdio.h>
#include <cs50.h>
#include <strings.h>
#include <string.h>
#include <ctype.h>

int POINTS[] = {1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};
void compute_score();

int main(void)
{
    string word1 = get_string("Player 1: ");
    string word2 = get_string("Player 2: ");
    compute_score(word1, word2);
}

void compute_score(string word1, string word2)
{
    int score1 = 0;
    int score2 = 0;
    for(int i = 0; i<strlen(word1); i++)
    {
        word1[i] = tolower(word1[i]);
        if (word1[i]=='a' || word1[i]=='b' || word1[i]=='i' || word1[i]=='l' || word1[i]=='n' || word1[i]=='o' || word1[i]=='r' || word1[i]=='s' || word1[i]=='t' || word1[i]=='u')
        {
            score1++;
        }
        else if (word1[i]=='b' || word1[i]=='c' || word1[i]=='m' || word1[i]=='p')
        {
            score1+=3;
        }
        else if (word1[i]=='d' || word1[i]=='g')
        {
            score1+=2;
        }
        else if (word1[i]=='f' || word1[i]=='h' || word1[i]=='v' || word1[i]=='w' || word1[i]=='y')
        {
            score1+=4;
        }
        else if (word1[i]=='j' || word1[i]=='x')
        {
            score1+=8;
        }
        else if (word1[i]=='k')
        {
            score1+=5;
        }
        else if (word1[i]=='q' || word1[i]=='z')
        {
            score1+=10;
        }
    }
    for(int j = 0; j<strlen(word2); j++)
    {
        word2[j] = tolower(word2[j]);

        if (word2[j]=='a' || word2[j]=='b' || word2[j]=='i' || word2[j]=='l' || word2[j]=='n' || word2[j]=='o' || word2[j]=='r' || word2[j]=='s' || word2[j]=='t' || word2[j]=='u')
        {
            score2++;
        }
        else if (word2[j]=='b' || word2[j]=='c' || word2[j]=='m' || word2[j]=='p')
        {
            score2+=3;
        }
        else if (word2[j]=='d' || word2[j]=='g')
        {
            score2+=2;
        }
        else if (word2[j]=='f' || word2[j]=='h' || word2[j]=='v' || word2[j]=='w' || word2[j]=='y')
        {
            score2+=4;
        }
        else if (word2[j]=='j' || word2[j]=='x')
        {
            score2+=8;
        }
        else if (word2[j]=='k')
        {
            score2+=5;
        }
        else if (word2[j]=='q' || word2[j]=='z')
        {
            score2+=10;
        }
    }
    if (score1>score2)
    {
        printf("Player 1 wins!\n");
    }
    else if (score2>score1)
    {
        printf("Player 2 wins!\n");
    }
    else
    {
        printf("Tie!\n");
    }
}
