#include <stdio.h>
#include <cs50.h>

int main(void)
{
    string name = get_string("Name: ");
    int age = get_int("Age: ");
    long phone_number = get_long("Phone Number: ");

    printf("Name is %s\nAge is %i\nPhone Number is %li\n",name,age,phone_number);
}