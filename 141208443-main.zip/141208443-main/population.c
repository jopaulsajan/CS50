#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int start;
    do
    {
         start=get_int("Start: ");
    }
    while (start<9);

    int end;
    do
    {
         end=get_int("End: ");
    }
    while(start>end);

    int years = 0;
    int cur = start;

    while (cur<end)
    {
        cur = cur + (cur/3) - (cur/4);
        years++;
    }
    printf("Years: %i\n",years);
}