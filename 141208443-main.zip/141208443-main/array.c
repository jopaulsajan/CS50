#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int size = get_int("Enter Array Size: ");
    int arr[size];
    arr[0] = 1;
    for(int j=0;j<size;j++)
    {
        arr[j+1] = 2*arr[j];
    }
    for(int i=0;i<size;i++)
    {
        printf("%i\n",arr[i]);
    }

}